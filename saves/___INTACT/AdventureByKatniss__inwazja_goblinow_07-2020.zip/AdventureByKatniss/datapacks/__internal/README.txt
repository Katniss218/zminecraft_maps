Dependencies:
- Katniss's Multipart Entity System
- Katniss's Unified Utility Pack